The plan is to eventually offer the same controls that webstatus does.

# Missing
 * Force Builds
 * The grid display
 * The waterfall display (replaced by a Timeline contributor for Trac)
