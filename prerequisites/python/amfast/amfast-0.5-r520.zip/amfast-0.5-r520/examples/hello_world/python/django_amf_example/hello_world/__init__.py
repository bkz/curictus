"""Hello World app showing off AmFast and Django."""
