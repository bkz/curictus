class Controller(object):
    def echo(self, val):
        return val

    def raiseException(self):
        raise Exception("Example Exception")
