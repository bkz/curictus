"""test file with non ascii characters and no encoding declaration"""

__revision__ = ''

YOP = 'h�h�h�'
