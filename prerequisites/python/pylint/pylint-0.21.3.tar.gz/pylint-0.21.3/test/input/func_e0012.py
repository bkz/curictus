# pylint:enable=W04044
"""check unknown option
"""
__revision__ = 1

