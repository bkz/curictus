"""check empty except statement
"""

__revision__ = 0

try:
    __revision__ += 1
except Exception:
    print 'error'
