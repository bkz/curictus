"""test local variable used before assignment
"""

__revision__ = 0

def function():
    """dummy"""
    print aaaa
    aaaa = 1
